import React, { useState, useEffect } from 'react';
import { 
  TrendingDown, 
  Calendar, 
  Hourglass, 
  ArrowRight, 
  Megaphone, 
  MessageSquare, 
  MessageCircle, 
  Headphones, 
  Globe,
  Sparkles,
  LayoutGrid
} from 'lucide-react';
import { NexlifyLogo } from './components/NexlifyLogo';
import { AuthModal } from './components/AuthModal';
import { ProductsServicesPage } from './components/ProductsServicesPage';
import { User } from './types';

export default function App() {
  const [lang, setLang] = useState<'en' | 'ar'>('en');
  const [currentView, setCurrentView] = useState<'landing' | 'products'>('landing');
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
  const [authInitialMode, setAuthInitialMode] = useState<'signup' | 'login'>('signup');
  const [currentUser, setCurrentUser] = useState<User | null>(() => {
    try {
      const saved = localStorage.getItem('nexlify_user');
      return saved ? JSON.parse(saved) : null;
    } catch {
      return null;
    }
  });

  const isRTL = lang === 'ar';

  useEffect(() => {
    if (currentUser) {
      localStorage.setItem('nexlify_user', JSON.stringify(currentUser));
    } else {
      localStorage.removeItem('nexlify_user');
    }
  }, [currentUser]);

  const handleOpenAuth = (mode: 'signup' | 'login' = 'signup') => {
    if (currentUser) {
      setCurrentView('products');
      window.scrollTo({ top: 0, behavior: 'smooth' });
    } else {
      setAuthInitialMode(mode);
      setIsAuthModalOpen(true);
    }
  };

  const handleAuthSuccess = (user: User) => {
    setCurrentUser(user);
    setIsAuthModalOpen(false);
    setCurrentView('products');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleLogout = () => {
    setCurrentUser(null);
    setCurrentView('landing');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const scrollToSection = (id: string) => {
    if (currentView !== 'landing') {
      setCurrentView('landing');
      setTimeout(() => {
        const el = document.getElementById(id);
        if (el) el.scrollIntoView({ behavior: 'smooth' });
      }, 100);
    } else {
      const el = document.getElementById(id);
      if (el) el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  // If user is viewing the Products & Services portal
  if (currentView === 'products' && currentUser) {
    return (
      <ProductsServicesPage
        user={currentUser}
        onLogout={handleLogout}
        onBackToHome={() => {
          setCurrentView('landing');
          window.scrollTo({ top: 0, behavior: 'smooth' });
        }}
        lang={lang}
        setLang={setLang}
      />
    );
  }

  // Otherwise render exact Landing Page matching the screenshots
  return (
    <div 
      id="nexlify-app" 
      className={`min-h-screen flex flex-col bg-white text-[#333333] selection:bg-[#D4AF37]/30 ${isRTL ? 'font-arabic' : 'font-sans'}`}
      dir={isRTL ? 'rtl' : 'ltr'}
      style={{ fontFamily: isRTL ? "'Tajawal', sans-serif" : "'Plus Jakarta Sans', sans-serif" }}
    >
      {/* HEADER / NAVIGATION */}
      <header id="main-navigation" className="sticky top-0 z-40 bg-white border-b border-gray-100 shadow-2xs">
        <div className="max-w-6xl mx-auto h-[68px] flex items-center justify-between px-6 lg:px-10">
          
          {/* Brand Logo */}
          <div 
            id="brand-logo" 
            className="flex items-center gap-2.5 cursor-pointer"
            onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
          >
            <NexlifyLogo size="sm" showWordmark={false} />
            <span className="font-extrabold text-lg text-[#0A1F3D] tracking-tight">Nexlify</span>
          </div>

          {/* Navigation Links */}
          <nav className="hidden md:flex items-center gap-8 text-xs font-semibold text-gray-600">
            <button 
              id="nav-how-it-works"
              onClick={() => scrollToSection('how-it-works-section')}
              className="hover:text-[#0A1F3D] transition-colors cursor-pointer"
            >
              {isRTL ? 'كيف يعمل' : 'How it Works'}
            </button>
            <button 
              id="nav-features"
              onClick={() => scrollToSection('features-section')}
              className="hover:text-[#0A1F3D] transition-colors cursor-pointer"
            >
              {isRTL ? 'المميزات' : 'Features'}
            </button>
            <button 
              id="nav-why-us"
              onClick={() => scrollToSection('cost-of-silence-section')}
              className="hover:text-[#0A1F3D] transition-colors cursor-pointer"
            >
              {isRTL ? 'لماذا نحن' : 'Why Us'}
            </button>
            <button 
              id="nav-pricing"
              onClick={() => handleOpenAuth('signup')}
              className="hover:text-[#0A1F3D] transition-colors cursor-pointer"
            >
              {isRTL ? 'الأسعار' : 'Pricing'}
            </button>
          </nav>

          {/* Header Action Button */}
          <div className="flex items-center gap-3">
            {currentUser && (
              <button
                id="header-portal-link"
                onClick={() => setCurrentView('products')}
                className="hidden sm:flex items-center gap-1.5 text-xs font-bold text-[#A37E36] hover:text-[#0A1F3D] px-2.5 py-1.5 rounded-md hover:bg-gray-50 transition-colors cursor-pointer"
              >
                <LayoutGrid className="w-3.5 h-3.5" />
                <span>{isRTL ? 'المنتجات والخدمات' : 'Products & Services'}</span>
              </button>
            )}

            <button
              id="header-book-demo-btn"
              onClick={() => handleOpenAuth('signup')}
              className="bg-[#0A1F3D] hover:bg-[#142c50] text-white px-4.5 py-2 rounded-md font-bold text-xs transition-colors shadow-xs cursor-pointer"
            >
              {isRTL ? 'ابدأ الآن' : 'Get Started'}
            </button>
          </div>
        </div>
      </header>

      {/* HERO SECTION */}
      <section id="hero-section" className="bg-white pt-16 pb-20 px-6 lg:px-10 text-center relative overflow-hidden">
        <div className="max-w-3xl mx-auto flex flex-col items-center">
          
          {/* Tag Pill */}
          <div 
            id="hero-badge" 
            className="inline-flex items-center px-3.5 py-1 rounded-sm bg-[#FAF4E6] border border-[#F2E5C9] text-[#A37E36] text-[10.5px] font-extrabold tracking-widest uppercase mb-6"
          >
            {isRTL ? 'أتمتة الذكاء الاصطناعي الفاخرة' : 'PREMIUM AI AUTOMATION'}
          </div>

          {/* Main Headline */}
          <h1 className="text-3xl sm:text-[42px] font-black text-[#0A1F3D] tracking-tight leading-[1.2] mb-5">
            {isRTL ? (
              <>وسائل التواصل لمتجرك، <br /><span className="text-[#0A1F3D]">على وضع </span><span className="text-[#CCA353]">الطيار الآلي</span></>
            ) : (
              <>Your Store's Social Media, <br /><span className="text-[#0A1F3D]">on </span><span className="text-[#CCA353]">Autopilot</span></>
            )}
          </h1>

          {/* Subtitle Description */}
          <p className="text-xs sm:text-[13.5px] text-gray-500 max-w-xl mx-auto leading-relaxed mb-8">
            {isRTL ? (
              'ذكاء اصطناعي يدير وسائل التواصل الاجتماعي لمتجرك بينما تتفرغ لتنمية عملك. أتمت الردود، جدول المنشورات، ولا تفوّت أي عملية بيع مع بنيتنا التحتية المتقدمة.'
            ) : (
              'AI that runs your social media while you run your business. Automate replies, schedule posts, and never miss a sale with our premium fintech-grade infrastructure.'
            )}
          </p>

          {/* Hero Buttons */}
          <div className="flex flex-wrap items-center justify-center gap-3.5">
            <button
              id="hero-book-demo-btn"
              onClick={() => handleOpenAuth('signup')}
              className="bg-[#D8AE5C] hover:bg-[#cb9f4b] text-[#0A1F3D] px-6 py-2.5 rounded-md font-bold text-xs transition-colors shadow-xs cursor-pointer"
            >
              {isRTL ? 'ابدأ الآن' : 'Get Started'}
            </button>
            <button
              id="hero-see-how-it-works-btn"
              onClick={() => scrollToSection('how-it-works-section')}
              className="bg-white hover:bg-gray-50 text-[#0A1F3D] border border-gray-300 px-5 py-2.5 rounded-md font-bold text-xs transition-colors flex items-center gap-1.5 cursor-pointer"
            >
              <span>{isRTL ? 'تعرف كيف يعمل' : 'See How It Works'}</span>
              <ArrowRight className={`w-3.5 h-3.5 text-[#0A1F3D] ${isRTL ? 'rotate-180' : ''}`} />
            </button>
          </div>

        </div>
      </section>

      {/* SECTION 2: THE COST OF SILENCE */}
      <section id="cost-of-silence-section" className="bg-[#F3F6FA] py-16 px-6 lg:px-10 border-t border-gray-100">
        <div className="max-w-5xl mx-auto">
          
          <h2 className="text-xl sm:text-2xl font-bold text-[#0A1F3D] text-center mb-10">
            {isRTL ? 'تكلفة الصمت وعدم الرد' : 'The Cost of Silence'}
          </h2>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            
            {/* Card 1: Missed DMs */}
            <div id="cost-card-1" className="bg-white p-6.5 rounded-xl border border-gray-100/90 shadow-xs flex flex-col justify-start">
              <div className="w-8 h-8 rounded-lg bg-rose-50 text-rose-500 flex items-center justify-center mb-4">
                <TrendingDown className="w-4 h-4" />
              </div>
              <h3 className="text-sm font-bold text-[#0A1F3D] mb-2">
                {isRTL ? 'تأخر الرد = خسارة المبيعات' : 'Missed DMs = Lost Sales'}
              </h3>
              <p className="text-xs text-gray-500 leading-relaxed">
                {isRTL 
                  ? 'كل دقيقة ينتظرها العميل للرد تزيد من احتمالية شرائه من أحد المنافسين.'
                  : 'Every minute a customer waits for a reply is a higher chance they buy from a competitor.'}
              </p>
            </div>

            {/* Card 2: Inconsistent Posting */}
            <div id="cost-card-2" className="bg-white p-6.5 rounded-xl border border-gray-100/90 shadow-xs flex flex-col justify-start">
              <div className="w-8 h-8 rounded-lg bg-sky-50 text-sky-500 flex items-center justify-center mb-4">
                <Calendar className="w-4 h-4" />
              </div>
              <h3 className="text-sm font-bold text-[#0A1F3D] mb-2">
                {isRTL ? 'النشر غير المنتظم' : 'Inconsistent Posting'}
              </h3>
              <p className="text-xs text-gray-500 leading-relaxed">
                {isRTL 
                  ? 'خوارزميات المنصات تعاقب الحسابات غير النشطة وتضعف وصول منشوراتك عند انقطاع النشر.'
                  : 'Algorithm penalties hurt visibility when your content schedule is erratic due to lack of time.'}
              </p>
            </div>

            {/* Card 3: Hours Wasted */}
            <div id="cost-card-3" className="bg-white p-6.5 rounded-xl border border-gray-100/90 shadow-xs flex flex-col justify-start">
              <div className="w-8 h-8 rounded-lg bg-indigo-50 text-indigo-500 flex items-center justify-center mb-4">
                <Hourglass className="w-4 h-4" />
              </div>
              <h3 className="text-sm font-bold text-[#0A1F3D] mb-2">
                {isRTL ? 'ساعات ضائعة في الردود المتكررة' : 'Hours Wasted on Repetitive Replies'}
              </h3>
              <p className="text-xs text-gray-500 leading-relaxed">
                {isRTL 
                  ? 'الإجابة اليدوية على نفس أسئلة الأسعار والمقاسات والتوصيل تستنزف طاقة فريقك.'
                  : 'Answering the same pricing and location questions drains energy meant for business growth.'}
              </p>
            </div>

          </div>

        </div>
      </section>

      {/* SECTION 3: FROM SETUP TO SALES IN 3 STEPS */}
      <section id="how-it-works-section" className="bg-white py-16 px-6 lg:px-10">
        <div className="max-w-5xl mx-auto text-center">
          
          <h2 className="text-xl sm:text-2xl font-bold text-[#0A1F3D] mb-2">
            {isRTL ? 'من الإعداد إلى زيادة المبيعات في 3 خطوات' : 'From Setup to Sales in 3 Steps'}
          </h2>
          <p className="text-xs sm:text-[13px] text-gray-500 max-w-md mx-auto mb-10 leading-relaxed">
            {isRTL 
              ? 'تكامل سهل ومباشر يضمن تشغيل متجرك بأتمتة كاملة خلال دقائق معدودة.'
              : 'Our streamlined onboarding ensures you are fully automated within minutes, not days.'}
          </p>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            
            {/* Step 1 */}
            <div id="step-card-1" className="bg-white p-7 rounded-xl border border-gray-100 shadow-xs border-t-2 border-t-[#D8AE5C]/50 flex flex-col items-center text-center">
              <div className="w-9 h-9 bg-[#0A1F3D] rotate-45 flex items-center justify-center mb-5 rounded-xs shadow-xs">
                <span className="-rotate-45 text-white font-bold text-xs">1</span>
              </div>
              <h3 className="text-sm font-bold text-[#0A1F3D] mb-2">
                {isRTL ? 'ربط الحسابات' : 'Connect Accounts'}
              </h3>
              <p className="text-xs text-gray-500 leading-relaxed">
                {isRTL 
                  ? 'اربط حساباتك في إنستغرام، فيسبوك، وتيك توك بأمان عبر الواجهات الرسمية (APIs).'
                  : 'Securely link your Instagram, Facebook, and TikTok profiles via official APIs.'}
              </p>
            </div>

            {/* Step 2 */}
            <div id="step-card-2" className="bg-white p-7 rounded-xl border border-gray-100 shadow-xs border-t-2 border-t-[#D8AE5C]/50 flex flex-col items-center text-center">
              <div className="w-9 h-9 bg-[#0A1F3D] rotate-45 flex items-center justify-center mb-5 rounded-xs shadow-xs">
                <span className="-rotate-45 text-white font-bold text-xs">2</span>
              </div>
              <h3 className="text-sm font-bold text-[#0A1F3D] mb-2">
                {isRTL ? 'الذكاء الاصطناعي يتولى الأمر' : 'AI Takes Over'}
              </h3>
              <p className="text-xs text-gray-500 leading-relaxed">
                {isRTL 
                  ? 'تتعلم نماذجنا الذكية بيانات منتجاتك وأسعارك لصياغة ردود ذكية متوافقة مع هوية متجرك.'
                  : 'Our models ingest your business data to formulate intelligent, brand-aligned responses.'}
              </p>
            </div>

            {/* Step 3 */}
            <div id="step-card-3" className="bg-white p-7 rounded-xl border border-gray-100 shadow-xs border-t-2 border-t-[#D8AE5C]/50 flex flex-col items-center text-center">
              <div className="w-9 h-9 bg-[#0A1F3D] rotate-45 flex items-center justify-center mb-5 rounded-xs shadow-xs">
                <span className="-rotate-45 text-white font-bold text-xs">3</span>
              </div>
              <h3 className="text-sm font-bold text-[#0A1F3D] mb-2">
                {isRTL ? 'شاهد نمو مبيعاتك' : 'Watch Sales Grow'}
              </h3>
              <p className="text-xs text-gray-500 leading-relaxed">
                {isRTL 
                  ? 'تمتع بتفاعل مستمر على مدار الساعة، ومعدلات تحويل أعلى، ووقت إضافي لأعمالك.'
                  : 'Enjoy 24/7 engagement, higher conversion rates, and reclaimed time.'}
              </p>
            </div>

          </div>

        </div>
      </section>

      {/* SECTION 4: INTELLIGENT AUTOMATION SUITE */}
      <section id="features-section" className="bg-[#F3F6FA] py-16 px-6 lg:px-10 border-t border-gray-100">
        <div className="max-w-5xl mx-auto">
          
          <h2 className="text-xl sm:text-2xl font-bold text-[#0A1F3D] text-center mb-10">
            {isRTL ? 'مجموعة حلول الأتمتة الذكية' : 'Intelligent Automation Suite'}
          </h2>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
            
            {/* Feature 1: Auto-Posting */}
            <div id="feature-auto-posting" className="bg-white p-6 rounded-xl border border-gray-100 shadow-xs flex items-start gap-4 hover:border-gray-200 transition-all">
              <div className="p-2 bg-amber-50 rounded-lg text-[#CCA353] shrink-0">
                <Megaphone className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-sm font-bold text-[#0A1F3D] mb-1.5">
                  {isRTL ? 'النشر التلقائي الذكي' : 'Auto-Posting'}
                </h3>
                <p className="text-xs text-gray-500 leading-relaxed">
                  {isRTL 
                    ? 'جدول محتوى لأسابيع قادمة عبر المنصات. يحلل الذكاء الاصطناعي أوقات نشاط جمهورك للنشر بأعلى وصول.'
                    : 'Schedule weeks of content across platforms. Our AI optimizes posting times based on audience activity data.'}
                </p>
              </div>
            </div>

            {/* Feature 2: Smart DM Reply */}
            <div id="feature-smart-dm" className="bg-white p-6 rounded-xl border border-gray-100 shadow-xs flex items-start gap-4 hover:border-gray-200 transition-all">
              <div className="p-2 bg-amber-50 rounded-lg text-[#CCA353] shrink-0">
                <MessageSquare className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-sm font-bold text-[#0A1F3D] mb-1.5">
                  {isRTL ? 'الرد الذكي على الرسائل الخاصة' : 'Smart DM Reply'}
                </h3>
                <p className="text-xs text-gray-500 leading-relaxed">
                  {isRTL 
                    ? 'ردود فورية تفهم سياق الاستفسارات، تجيب على تفاصيل المنتجات، وتحول العميل لموظف بشري عند الحاجة.'
                    : 'Context-aware responses to inquiries, capable of handling complex product questions and routing to human agents when necessary.'}
                </p>
              </div>
            </div>

            {/* Feature 3: Comment-to-DM */}
            <div id="feature-comment-to-dm" className="bg-white p-6 rounded-xl border border-gray-100 shadow-xs flex items-start gap-4 hover:border-gray-200 transition-all">
              <div className="p-2 bg-amber-50 rounded-lg text-[#CCA353] shrink-0">
                <MessageCircle className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-sm font-bold text-[#0A1F3D] mb-1.5">
                  {isRTL ? 'تحويل التعليقات إلى رسائل خاصة' : 'Comment-to-DM Automation'}
                </h3>
                <p className="text-xs text-gray-500 leading-relaxed">
                  {isRTL 
                    ? 'إرسال رسائل خاصة فورية لكل من يعلق بكلمات معينة، مما يحول التعليقات العادية لطلبات بيع فورية.'
                    : 'Automatically slide into the DMs of users who comment specific keywords, driving private sales conversations instantly.'}
                </p>
              </div>
            </div>

            {/* Feature 4: 24/7 Availability */}
            <div id="feature-24-7" className="bg-white p-6 rounded-xl border border-gray-100 shadow-xs flex items-start gap-4 hover:border-gray-200 transition-all">
              <div className="p-2 bg-amber-50 rounded-lg text-[#CCA353] shrink-0">
                <Headphones className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-sm font-bold text-[#0A1F3D] mb-1.5">
                  {isRTL ? 'جاهزية على مدار 24/7' : '24/7 Availability'}
                </h3>
                <p className="text-xs text-gray-500 leading-relaxed">
                  {isRTL 
                    ? 'متجرك لا ينام أبداً. استغل رغبات الشراء الليلية والزيارات الدولية بالتفاعل السريع المباشر.'
                    : 'Your storefront never sleeps. Capitalize on late-night impulses and international traffic with instant engagement.'}
                </p>
              </div>
            </div>

          </div>

        </div>
      </section>

      {/* FOOTER */}
      <footer id="main-footer" className="bg-white py-10 px-6 lg:px-10 border-t border-gray-100">
        <div className="max-w-5xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-6">
          
          {/* Left Footer Info */}
          <div className="flex flex-col items-center sm:items-start">
            <span className="font-extrabold text-sm text-[#0A1F3D]">Nexlify</span>
            <span className="text-xs text-gray-400 mt-1">
              &copy; {new Date().getFullYear()} Nexlify AI. {isRTL ? 'جميع الحقوق محفوظة.' : 'All rights reserved.'}
            </span>
          </div>

          {/* Right Footer Links */}
          <div className="flex items-center gap-6 text-xs text-gray-500 font-medium">
            <a href="#privacy" onClick={(e) => { e.preventDefault(); }} className="hover:text-[#0A1F3D] transition-colors">
              {isRTL ? 'سياسة الخصوصية' : 'Privacy Policy'}
            </a>
            <a href="#terms" onClick={(e) => { e.preventDefault(); }} className="hover:text-[#0A1F3D] transition-colors">
              {isRTL ? 'شروط الخدمة' : 'Terms of Service'}
            </a>
            <a href="#contact" onClick={(e) => { e.preventDefault(); handleOpenAuth('signup'); }} className="hover:text-[#0A1F3D] transition-colors">
              {isRTL ? 'تواصل معنا' : 'Contact Us'}
            </a>
            <button
              id="footer-language-btn"
              onClick={() => setLang(l => l === 'en' ? 'ar' : 'en')}
              className="text-[#0A1F3D] font-bold hover:underline cursor-pointer"
            >
              {isRTL ? 'English' : 'العربية'}
            </button>
          </div>

        </div>
      </footer>

      {/* AUTHENTICATION & LOGIN MODAL */}
      <AuthModal
        isOpen={isAuthModalOpen}
        onClose={() => setIsAuthModalOpen(false)}
        onSuccess={handleAuthSuccess}
        initialMode={authInitialMode}
        isRTL={isRTL}
      />
    </div>
  );
}
