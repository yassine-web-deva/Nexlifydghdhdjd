export interface User {
  name: string;
  email: string;
  storeName: string;
  platform: string;
  plan: 'Starter' | 'Scale' | 'Enterprise';
  region: string;
  avatar?: string;
  createdAt: string;
}

export interface ProductItem {
  id: string;
  titleEn: string;
  titleAr: string;
  category: 'automation' | 'publishing' | 'commerce' | 'services';
  categoryLabelEn: string;
  categoryLabelAr: string;
  descEn: string;
  descAr: string;
  iconName: string;
  badge?: string;
  badgeType?: 'active' | 'popular' | 'new' | 'enterprise';
  featuresEn: string[];
  featuresAr: string[];
  metrics?: { labelEn: string; labelAr: string; value: string };
  priceMonthly?: string;
}
