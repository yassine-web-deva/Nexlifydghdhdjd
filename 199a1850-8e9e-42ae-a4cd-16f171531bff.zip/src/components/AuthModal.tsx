import React, { useState } from 'react';
import { X, Lock, Mail, User as UserIcon, Store, Globe, ArrowRight, Check, Sparkles } from 'lucide-react';
import { NexlifyLogo } from './NexlifyLogo';
import { User } from '../types';

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: (user: User) => void;
  initialMode?: 'signup' | 'login';
  isRTL: boolean;
}

export const AuthModal: React.FC<AuthModalProps> = ({
  isOpen,
  onClose,
  onSuccess,
  initialMode = 'signup',
  isRTL
}) => {
  const [mode, setMode] = useState<'signup' | 'login'>(initialMode);
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    password: '',
    storeName: '',
    platform: 'Instagram',
    region: 'Saudi Arabia 🇸🇦'
  });
  const [isLoading, setIsLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');

    if (mode === 'signup' && (!formData.name.trim() || !formData.storeName.trim())) {
      setErrorMsg(isRTL ? 'يرجى تعبئة جميع الحقول المطلوبة' : 'Please fill in all required fields');
      return;
    }

    if (!formData.email.trim() || !formData.password.trim()) {
      setErrorMsg(isRTL ? 'يرجى إدخال البريد الإلكتروني وكلمة المرور' : 'Please enter your email and password');
      return;
    }

    setIsLoading(true);

    setTimeout(() => {
      setIsLoading(false);
      const user: User = {
        name: formData.name.trim() || (mode === 'login' ? 'Sarah Al-Otaibi' : 'Store Owner'),
        email: formData.email.trim(),
        storeName: formData.storeName.trim() || (mode === 'login' ? '@luxuryabaya.sa' : '@mystore.gcc'),
        platform: formData.platform,
        plan: 'Scale',
        region: formData.region,
        createdAt: new Date().toLocaleDateString()
      };
      onSuccess(user);
    }, 650);
  };

  const handleQuickDemoAccess = () => {
    setIsLoading(true);
    setTimeout(() => {
      setIsLoading(false);
      const demoUser: User = {
        name: 'Sarah Al-Otaibi',
        email: 'sarah@aloud-luxury.sa',
        storeName: '@aloud.luxury',
        platform: 'Instagram & Salla',
        plan: 'Scale',
        region: 'Riyadh, KSA 🇸🇦',
        createdAt: new Date().toLocaleDateString()
      };
      onSuccess(demoUser);
    }, 400);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/65 backdrop-blur-xs p-4 animate-in fade-in duration-200">
      <div 
        className="bg-white rounded-2xl max-w-md w-full p-6 sm:p-7 shadow-2xl border border-gray-200 relative overflow-hidden"
        dir={isRTL ? 'rtl' : 'ltr'}
      >
        {/* Subtle top gold decorative accent */}
        <div className="absolute top-0 left-0 right-0 h-1.5 bg-gradient-to-r from-[#0A1F3D] via-[#D8AE5C] to-[#0A1F3D]"></div>

        {/* Close Button */}
        <button
          id="close-auth-modal"
          onClick={onClose}
          className="absolute top-4 right-4 text-gray-400 hover:text-gray-700 p-1.5 rounded-lg hover:bg-gray-100 transition-colors"
        >
          <X className="w-4.5 h-4.5" />
        </button>

        {/* Header Branding */}
        <div className="flex items-center gap-2.5 mb-5">
          <NexlifyLogo size="sm" showWordmark={false} />
          <span className="font-extrabold text-base text-[#0A1F3D] tracking-tight">Nexlify</span>
          <span className="text-[10px] bg-[#FAF4E6] text-[#A37E36] font-bold px-2 py-0.5 rounded border border-[#F2E5C9]">
            {isRTL ? 'بوابة الأعمال' : 'Merchant Portal'}
          </span>
        </div>

        {/* Tabs: Create Account vs Log In */}
        <div className="flex bg-gray-100 p-1 rounded-lg mb-5">
          <button
            type="button"
            id="tab-signup"
            onClick={() => { setMode('signup'); setErrorMsg(''); }}
            className={`flex-1 py-2 text-xs font-bold rounded-md transition-all ${
              mode === 'signup'
                ? 'bg-white text-[#0A1F3D] shadow-xs'
                : 'text-gray-500 hover:text-gray-800'
            }`}
          >
            {isRTL ? 'إنشاء حساب جديد' : 'Create Account'}
          </button>
          <button
            type="button"
            id="tab-login"
            onClick={() => { setMode('login'); setErrorMsg(''); }}
            className={`flex-1 py-2 text-xs font-bold rounded-md transition-all ${
              mode === 'login'
                ? 'bg-white text-[#0A1F3D] shadow-xs'
                : 'text-gray-500 hover:text-gray-800'
            }`}
          >
            {isRTL ? 'تسجيل الدخول' : 'Log In'}
          </button>
        </div>

        {/* Headline */}
        <div className="mb-4">
          <h3 className="text-lg font-black text-[#0A1F3D]">
            {mode === 'signup' 
              ? (isRTL ? 'ابدأ أتمتة مبيعات متجرك' : 'Get Started with Nexlify')
              : (isRTL ? 'مرحباً بك مجدداً' : 'Welcome Back')}
          </h3>
          <p className="text-xs text-gray-500 mt-0.5">
            {mode === 'signup'
              ? (isRTL ? 'أنشئ حسابك للوصول إلى كافة المنتجات والخدمات الذكية' : 'Create your account to access our complete suite of products and services.')
              : (isRTL ? 'سجل دخولك لإدارة أتمتة متجرك والاطلاع على الخدمات' : 'Log in to manage your automation workflows and access products.')}
          </p>
        </div>

        {errorMsg && (
          <div className="mb-3.5 p-2.5 rounded-lg bg-rose-50 border border-rose-200 text-rose-600 text-xs font-medium">
            {errorMsg}
          </div>
        )}

        {/* Form */}
        <form onSubmit={handleSubmit} className="space-y-3">
          {mode === 'signup' && (
            <>
              <div>
                <label className="block text-[11px] font-bold text-gray-700 mb-1">
                  {isRTL ? 'الاسم الكامل' : 'Full Name'}
                </label>
                <div className="relative">
                  <UserIcon className="w-3.5 h-3.5 text-gray-400 absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    required
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    placeholder="e.g. Sarah Al-Otaibi"
                    className="w-full bg-gray-50 border border-gray-200 rounded-lg pl-9 pr-3 py-2 text-xs text-gray-800 focus:outline-none focus:border-[#0A1F3D] focus:bg-white transition-all"
                  />
                </div>
              </div>

              <div>
                <label className="block text-[11px] font-bold text-gray-700 mb-1">
                  {isRTL ? 'اسم المتجر / حساب الإنستغرام' : 'Store / Instagram Handle'}
                </label>
                <div className="relative">
                  <Store className="w-3.5 h-3.5 text-gray-400 absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    required
                    value={formData.storeName}
                    onChange={(e) => setFormData({ ...formData, storeName: e.target.value })}
                    placeholder="e.g. @aloud_store or aloud.com"
                    className="w-full bg-gray-50 border border-gray-200 rounded-lg pl-9 pr-3 py-2 text-xs text-gray-800 focus:outline-none focus:border-[#0A1F3D] focus:bg-white transition-all"
                  />
                </div>
              </div>
            </>
          )}

          <div>
            <label className="block text-[11px] font-bold text-gray-700 mb-1">
              {isRTL ? 'البريد الإلكتروني' : 'Email Address'}
            </label>
            <div className="relative">
              <Mail className="w-3.5 h-3.5 text-gray-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="email"
                required
                value={formData.email}
                onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                placeholder="sarah@store.com"
                className="w-full bg-gray-50 border border-gray-200 rounded-lg pl-9 pr-3 py-2 text-xs text-gray-800 focus:outline-none focus:border-[#0A1F3D] focus:bg-white transition-all"
              />
            </div>
          </div>

          <div>
            <label className="block text-[11px] font-bold text-gray-700 mb-1">
              {isRTL ? 'كلمة المرور' : 'Password'}
            </label>
            <div className="relative">
              <Lock className="w-3.5 h-3.5 text-gray-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="password"
                required
                value={formData.password}
                onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                placeholder="••••••••"
                className="w-full bg-gray-50 border border-gray-200 rounded-lg pl-9 pr-3 py-2 text-xs text-gray-800 focus:outline-none focus:border-[#0A1F3D] focus:bg-white transition-all"
              />
            </div>
          </div>

          {mode === 'signup' && (
            <div className="grid grid-cols-2 gap-2 pt-1">
              <div>
                <label className="block text-[10px] font-bold text-gray-600 mb-1">
                  {isRTL ? 'المنصة الرئيسية' : 'Primary Platform'}
                </label>
                <select
                  value={formData.platform}
                  onChange={(e) => setFormData({ ...formData, platform: e.target.value })}
                  className="w-full bg-gray-50 border border-gray-200 rounded-lg px-2.5 py-1.5 text-xs text-gray-800 focus:outline-none focus:border-[#0A1F3D]"
                >
                  <option value="Instagram">Instagram DM</option>
                  <option value="WhatsApp">WhatsApp Business</option>
                  <option value="Salla">Salla (سلة)</option>
                  <option value="Zid">Zid (زد)</option>
                  <option value="Shopify">Shopify</option>
                </select>
              </div>

              <div>
                <label className="block text-[10px] font-bold text-gray-600 mb-1">
                  {isRTL ? 'المنطقة' : 'Region'}
                </label>
                <select
                  value={formData.region}
                  onChange={(e) => setFormData({ ...formData, region: e.target.value })}
                  className="w-full bg-gray-50 border border-gray-200 rounded-lg px-2.5 py-1.5 text-xs text-gray-800 focus:outline-none focus:border-[#0A1F3D]"
                >
                  <option value="Saudi Arabia 🇸🇦">Saudi Arabia 🇸🇦</option>
                  <option value="United Arab Emirates 🇦🇪">UAE 🇦🇪</option>
                  <option value="Kuwait 🇰🇼">Kuwait 🇰🇼</option>
                  <option value="Qatar 🇶🇦">Qatar 🇶🇦</option>
                  <option value="Other">Global / Other</option>
                </select>
              </div>
            </div>
          )}

          {/* Submit Button */}
          <button
            type="submit"
            id="auth-submit-btn"
            disabled={isLoading}
            className="w-full mt-2 bg-[#0A1F3D] hover:bg-[#142c50] text-white py-2.5 rounded-lg font-bold text-xs flex items-center justify-center gap-2 transition-all shadow-md active:scale-98 disabled:opacity-75"
          >
            {isLoading ? (
              <span className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin"></span>
            ) : (
              <>
                <span>
                  {mode === 'signup' 
                    ? (isRTL ? 'إنشاء الحساب ومتابعة المنتجات' : 'Create Account & View Products')
                    : (isRTL ? 'تسجيل الدخول' : 'Log In & View Products')}
                </span>
                <ArrowRight className={`w-3.5 h-3.5 text-[#D8AE5C] ${isRTL ? 'rotate-180' : ''}`} />
              </>
            )}
          </button>
        </form>

        {/* Quick Demo Access Bar */}
        <div className="mt-4 pt-3.5 border-t border-gray-100 flex items-center justify-between text-xs">
          <span className="text-[11px] text-gray-400">
            {isRTL ? 'تريد تجربة سريعة؟' : 'Instant preview?'}
          </span>
          <button
            type="button"
            id="quick-demo-access-btn"
            onClick={handleQuickDemoAccess}
            className="text-[11px] font-bold text-[#A37E36] hover:text-[#0A1F3D] flex items-center gap-1 hover:underline cursor-pointer"
          >
            <Sparkles className="w-3 h-3 text-[#D8AE5C]" />
            <span>{isRTL ? 'دخول فوري بحساب تجريبي' : 'One-Click Demo Sign In'}</span>
          </button>
        </div>

      </div>
    </div>
  );
};
