import React, { useState } from 'react';
import { 
  Bot, 
  MessageSquare, 
  Calendar, 
  CreditCard, 
  Cpu, 
  Sparkles, 
  ShieldCheck, 
  CheckCircle2, 
  Layers, 
  Zap, 
  ArrowLeft, 
  Globe, 
  LogOut, 
  Sliders, 
  ExternalLink, 
  Check, 
  Play, 
  Send,
  HelpCircle,
  Clock,
  Headphones,
  Settings,
  ChevronRight
} from 'lucide-react';
import { NexlifyLogo } from './NexlifyLogo';
import { User, ProductItem } from '../types';

interface ProductsServicesPageProps {
  user: User;
  onLogout: () => void;
  onBackToHome: () => void;
  lang: 'en' | 'ar';
  setLang: React.Dispatch<React.SetStateAction<'en' | 'ar'>>;
}

const PRODUCTS_DATA: ProductItem[] = [
  {
    id: 'ai-dm-auto-responder',
    category: 'automation',
    categoryLabelEn: 'Core AI Automation',
    categoryLabelAr: 'أتمتة الذكاء الاصطناعي',
    titleEn: 'Nexlify Conversational AI Engine',
    titleAr: 'محرك الرد الذكي على المحادثات (DM Engine)',
    descEn: 'Bilingual AI engine trained on GCC consumer behavior to handle inquiries, recommend items, and close sales on Instagram & WhatsApp.',
    descAr: 'محرك ذكاء اصطناعي ثنائي اللغة يفهم اللهجات الخليجية بدقة، يقترح المنتجات للعملاء، ويتمم المبيعات على إنستغرام وواتساب 24/7.',
    iconName: 'Bot',
    badge: 'ACTIVE & LIVE',
    badgeType: 'active',
    featuresEn: [
      'Sub-second response latency (0.8s avg)',
      'Understands Saudi (Najdi/Hejazi), Emirati, and Gulf dialects',
      'Instant human handoff for edge cases',
      'Multi-currency & GCC shipping calculation'
    ],
    featuresAr: [
      'سرعة استجابة فائقة (متوسط 0.8 ثانية)',
      'فهم كامل للهجات (نجدية، حجازية، إماراتية، وخليجية)',
      'تحويل فوري لموظف خدمة العملاء للحالات الخاصة',
      'حساب تكاليف الشحن وتعدد العملات الخليجية'
    ],
    metrics: { labelEn: 'Average Conversion Lift', labelAr: 'زيادة معدل التحويل', value: '+34%' },
    priceMonthly: '$199 / mo'
  },
  {
    id: 'comment-to-dm-converter',
    category: 'automation',
    categoryLabelEn: 'Core AI Automation',
    categoryLabelAr: 'أتمتة الذكاء الاصطناعي',
    titleEn: 'Comment-to-DM Viral Sales Pipeline',
    titleAr: 'محول التعليقات إلى رسائل خاصة ومبيعات',
    descEn: 'Automatically detects buyer keywords on Instagram Reels, TikTok, and Facebook posts, instantly sending private product links and discount codes.',
    descAr: 'يراقب الكلمات المفتاحية في تعليقات مقاطع الريلز والمنشورات ويرسل رابط الشراء وكود الخصم في الخاص بشكل فوري وآلي.',
    iconName: 'MessageSquare',
    badge: 'HIGH ROI',
    badgeType: 'popular',
    featuresEn: [
      'Keyword trigger detection ("price", "link", "how much", "سعر")',
      'Automated public comment reply to boost post algorithmic reach',
      'Direct Apple Pay & Mada checkout link generation in DM',
      'Anti-spam and Meta policy compliant rate limiting'
    ],
    featuresAr: [
      'التعرف على كلمات الشراء ("سعر", "رابط", "كم", "تفاصيل")',
      'رد تلقائي على التعليق لزيادة وصول المنشور في خوارزمية إنستغرام',
      'توليد رابط دفع فوري يدعم Apple Pay ومدى بالخاص',
      'متوافق 100% مع سياسات وشروط Meta الرسمية'
    ],
    metrics: { labelEn: 'Lead Capture Rate', labelAr: 'معدل التقاط المشترين', value: '98.2%' },
    priceMonthly: '$99 / mo'
  },
  {
    id: 'ai-content-scheduler',
    category: 'publishing',
    categoryLabelEn: 'Content & Publishing',
    categoryLabelAr: 'المحتوى والنشر الذكي',
    titleEn: 'AI Social Scheduler & Copywriter',
    titleAr: 'مجدول المحتوى وكاتب الإعلانات بالذكاء الاصطناعي',
    descEn: 'Generates high-engagement Arabic/English captions tailored to GCC market trends and auto-publishes at peak traffic hours.',
    descAr: 'يولد نصوصاً إعلانية جذابة باللهجات المحلية وينشر المنشورات في أوقات ذروة تفاعل الجمهور الخليجي تلقائياً.',
    iconName: 'Calendar',
    badge: 'SMART TIMING',
    badgeType: 'new',
    featuresEn: [
      'Generates engaging product hooks & GCC hashtag packs',
      'Auto-optimizes publish times for Riyadh & Dubai peak hours',
      'Cross-platform publishing (Instagram, TikTok, Facebook)',
      'Visual asset grid preview and carousel support'
    ],
    featuresAr: [
      'توليد نصوص إعلانية مبتكرة مع هاشتاقات ترند خليجية',
      'تحديد أفضل أوقات النشر في الرياض ودبي تلقائياً',
      'النشر الموحد على إنستغرام وتيك توك وفيسبوك',
      'معاينة بصرية مسبقة للمنشورات وترتيب الكاروسيل'
    ],
    metrics: { labelEn: 'Organic Reach Boost', labelAr: 'زيادة الوصول الطبيعي', value: '+45%' },
    priceMonthly: '$120 / mo'
  },
  {
    id: 'gcc-checkout-sync',
    category: 'commerce',
    categoryLabelEn: 'Commerce & Payments',
    categoryLabelAr: 'التجارة والدفع الفوري',
    titleEn: 'Direct In-Chat Checkout & Sync Engine',
    titleAr: 'محرك الدفع السريع ومزامنة المخزون',
    descEn: 'Instant checkout links for Salla, Zid, and Shopify with real-time inventory checking and support for Apple Pay, Mada, Tamara, and Tabby.',
    descAr: 'توليد روابط سريعة لإتمام الطلب من سلة وزد وشوبيفاي مع فحص المخزون لحظياً ودعم تابي وتمارا والدفع عند الاستلام.',
    iconName: 'CreditCard',
    badge: 'ECOSYSTEM NATIVE',
    badgeType: 'active',
    featuresEn: [
      'Live SKU & stock availability sync with Salla / Zid / Shopify',
      'One-tap payment links (Apple Pay, Mada, Credit Cards)',
      'Tamara & Tabby BNPL installment integration in DM',
      'Real-time order tracking and invoice delivery'
    ],
    featuresAr: [
      'مزامنة فورية لكميات المخزون مع منصات سلة وزد وشوبيفاي',
      'روابط دفع بنقرة واحدة تدعم Apple Pay ومدى والبطاقات',
      'دعم الدفع الآجل عبر تمارا وتابي داخل المحادثة',
      'تتبع مسار الشحنات وإرسال الفواتير التلقائية للعميل'
    ],
    metrics: { labelEn: 'Abandoned Cart Recovery', labelAr: 'استرداد السلات المتروكة', value: '+28%' },
    priceMonthly: '$149 / mo'
  },
  {
    id: 'dialect-ai-studio',
    category: 'automation',
    categoryLabelEn: 'Core AI Automation',
    categoryLabelAr: 'أتمتة الذكاء الاصطناعي',
    titleEn: 'Custom Dialect & Tone Customizer',
    titleAr: 'استوديو تخصيص اللهجات ونبرة البراند',
    descEn: 'Train your AI to speak exactly in your brand tone—whether luxury formal Arabic, friendly Najdi, warm Emirati, or bilingual modern English.',
    descAr: 'تخصيص نبرة صوت ومفردات الذكاء الاصطناعي بما يطابق هوية متجرك بالضبط (فخمة، ودية، نجدية، إماراتية، أو إنجليزية معربة).',
    iconName: 'Cpu',
    badge: 'PRO EXCLUSIVE',
    badgeType: 'popular',
    featuresEn: [
      'Preset dialect modes: Najdi, Hejazi, Emirati, Kuwaiti, Modern Standard',
      'Custom FAQ & brand vocabulary training',
      'Emoji frequency & greeting tone controls',
      'Negative prompt filters (prevents competitor mentions)'
    ],
    featuresAr: [
      'لهجات جاهزة: نجدية، حجازية، إماراتية، كويتية، فصحى معاصرة',
      'تدريب مخصص على الأسئلة الشائعة ومصطلحات متجرك',
      'التحكم في أسلوب الترحيب وكثافة استخدام الإيموجي',
      'فلاتر ذكية لمنع ذكر المنافسين أو الأخطاء الشائعة'
    ],
    metrics: { labelEn: 'Customer Satisfaction', labelAr: 'رضا العملاء', value: '4.9/5' },
    priceMonthly: 'Included in Scale'
  },
  {
    id: 'managed-setup-onboarding',
    category: 'services',
    categoryLabelEn: 'Managed Services',
    categoryLabelAr: 'الخدمات الاحترافية المدارة',
    titleEn: 'Done-For-You VIP Setup & Catalogue Ingestion',
    titleAr: 'خدمة الإعداد الشامل وتهيئة الكتالوج (VIP)',
    descEn: 'Our senior GCC e-commerce engineers handle your full setup: WhatsApp Cloud API verification, Salla/Zid webhook bridges, and custom AI prompt engineering.',
    descAr: 'يقوم مهندسونا بربط متجرك بالكامل: توثيق العلامة الخضراء في واتساب، ربط المنصات بسلاسة، وهندسة الأوامر الذكية لمنتجاتك.',
    iconName: 'Sparkles',
    badge: 'WHITE GLOVE',
    badgeType: 'enterprise',
    featuresEn: [
      'Official Meta WhatsApp Business API green-tick guidance',
      'Full catalog ingestion up to 5,000 SKUs',
      'A/B testing of highest converting sales prompts',
      'Dedicated Slack/WhatsApp channel with assigned solutions engineer'
    ],
    featuresAr: [
      'مساعدة في توثيق الحساب التجاري والعلامة الخضراء من Meta',
      'تغذية الذكاء الاصطناعي بكامل كتالوج منتجاتك (حتى 5,000 منتج)',
      'اختبارات A/B لأفضل السيناريوهات المحققة لأعلى مبيعات',
      'قناة تواصل خاصة ومباشرة عبر الواتساب مع مهندس الدعم المخصص'
    ],
    metrics: { labelEn: 'Go-Live Turnaround', labelAr: 'مدة الإطلاق والتسليم', value: '48 Hours' },
    priceMonthly: '$499 One-Time'
  },
  {
    id: 'priority-arabic-sla',
    category: 'services',
    categoryLabelEn: 'Managed Services',
    categoryLabelAr: 'الخدمات الاحترافية المدارة',
    titleEn: '24/7 Priority Arabic Merchant Support SLA',
    titleAr: 'دعم فني مخصص ذو أولوية على مدار الساعة (SLA)',
    descEn: 'Round-the-clock technical monitoring and instant assistance in Arabic and English for high-volume stores during GCC flash sales & Ramadan campaigns.',
    descAr: 'مراقبة تقنية مستمرة لضمان عدم توقف المحادثات أثناء حملات التخفيضات ومواسم رمضان والجمعة البيضاء.',
    iconName: 'Headphones',
    badge: 'GUARANTEED SLA',
    badgeType: 'enterprise',
    featuresEn: [
      'Guaranteed <15 minute response time SLA',
      'Campaign surge scaling for high-traffic sales peaks',
      'Dedicated bilingual account strategist',
      'Monthly conversion rate optimization (CRO) report'
    ],
    featuresAr: [
      'استجابة مضمونة في أقل من 15 دقيقة طوال أيام الأسبوع',
      'رفع السعة التلقائية في مواسم التخفيضات الكبرى',
      'مستشار تجارة إلكترونية مخصص لنمو مبيعاتك',
      'تقرير شهري تفصيلي لتحسين معدلات الشراء من المحادثات'
    ],
    metrics: { labelEn: 'Uptime Guarantee', labelAr: 'ضمان الاستقرار والعمل', value: '99.9%' },
    priceMonthly: 'Included in Scale'
  }
];

export const ProductsServicesPage: React.FC<ProductsServicesPageProps> = ({
  user,
  onLogout,
  onBackToHome,
  lang,
  setLang
}) => {
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [activeConfigModal, setActiveConfigModal] = useState<ProductItem | null>(null);
  const [activatedProducts, setActivatedProducts] = useState<string[]>(['ai-dm-auto-responder', 'comment-to-dm-converter']);
  
  // Interactive Live Tester in Modal State
  const [testInput, setTestInput] = useState('');
  const [testChatLog, setTestChatLog] = useState<{ role: 'user' | 'ai'; text: string; time: string }[]>([
    { role: 'user', text: lang === 'ar' ? 'كم سعر العباية الحرير مع التوصيل للرياض؟' : 'How much for the silk abaya with Riyadh delivery?', time: '12:00 PM' },
    { role: 'ai', text: lang === 'ar' ? 'أهلاً بك! سعر العباية 390 ريال والشحن مجاني للرياض اليوم. هل ترغب برابط دفع فوري عبر Apple Pay؟ 🛍️' : 'Hello! The abaya is 390 SAR with complimentary same-day Riyadh delivery. Would you like a direct Apple Pay checkout link? 🛍️', time: '12:00 PM' }
  ]);
  const [isAiTyping, setIsAiTyping] = useState(false);

  const isRTL = lang === 'ar';

  const filteredProducts = PRODUCTS_DATA.filter(item => {
    const matchesCategory = selectedCategory === 'all' || item.category === selectedCategory;
    const matchesSearch = 
      item.titleEn.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.titleAr.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.descEn.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.descAr.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  const toggleActivateProduct = (id: string) => {
    setActivatedProducts(prev => 
      prev.includes(id) ? prev.filter(item => item !== id) : [...prev, id]
    );
  };

  const handleTestSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!testInput.trim()) return;

    const query = testInput.trim();
    setTestInput('');
    setTestChatLog(prev => [
      ...prev,
      { role: 'user', text: query, time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) }
    ]);

    setIsAiTyping(true);
    setTimeout(() => {
      let reply = '';
      const lower = query.toLowerCase();
      if (lower.includes('سعر') || lower.includes('كم') || lower.includes('price')) {
        reply = isRTL 
          ? 'السعر 290 ريال مع شحن مجاني للطلبات فوق 200 ريال! كود الخصم (NEX10) مفعّل الآن.'
          : 'The item is 290 AED/SAR with free GCC shipping on orders above 200 AED! Special voucher (NEX10) applied.';
      } else if (lower.includes('توصيل') || lower.includes('shipping') || lower.includes('delivery')) {
        reply = isRTL 
          ? 'نوفر التوصيل السريع لجميع مدن السعودية والإمارات خلال 24-48 ساعة، والدفع عند الاستلام متاح.'
          : 'We offer express 24-48 hour delivery across UAE, KSA, and Kuwait with Cash on Delivery and Apple Pay.';
      } else {
        reply = isRTL 
          ? `شكراً لتواصلك مع ${user.storeName}! تم تسجيل استفسارك وسيقوم نظام نكستليفاي الذكي بتجهيز خيارات المقاس والشحن الفوري الآن.`
          : `Thanks for reaching out to ${user.storeName}! Nexlify AI has identified your request and prepared tailored options.`;
      }

      setTestChatLog(prev => [
        ...prev,
        { role: 'ai', text: reply, time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) }
      ]);
      setIsAiTyping(false);
    }, 700);
  };

  return (
    <div 
      id="products-services-portal"
      className={`min-h-screen bg-[#F8FAFC] text-[#1E293B] flex flex-col selection:bg-[#D8AE5C]/30 ${isRTL ? 'font-arabic' : 'font-sans'}`}
      dir={isRTL ? 'rtl' : 'ltr'}
      style={{ fontFamily: isRTL ? "'Tajawal', sans-serif" : "'Plus Jakarta Sans', sans-serif" }}
    >
      {/* PORTAL TOP NAVIGATION */}
      <header id="portal-header" className="sticky top-0 z-40 bg-white border-b border-gray-200/90 shadow-2xs">
        <div className="max-w-7xl mx-auto h-[70px] flex items-center justify-between px-6 lg:px-10">
          
          {/* Left: Brand & Return link */}
          <div className="flex items-center gap-6">
            <div 
              className="flex items-center gap-2.5 cursor-pointer"
              onClick={onBackToHome}
            >
              <NexlifyLogo size="sm" showWordmark={false} />
              <span className="font-black text-lg text-[#0A1F3D] tracking-tight">Nexlify</span>
            </div>

            <div className="hidden md:block h-5 w-[1px] bg-gray-200"></div>

            <button
              id="back-to-landing-btn"
              onClick={onBackToHome}
              className="hidden md:flex items-center gap-1.5 text-xs font-bold text-gray-500 hover:text-[#0A1F3D] transition-colors cursor-pointer"
            >
              <ArrowLeft className={`w-3.5 h-3.5 ${isRTL ? 'rotate-180' : ''}`} />
              <span>{isRTL ? 'العودة للرئيسية' : 'Back to Home'}</span>
            </button>
          </div>

          {/* Center: Title Pill */}
          <div className="hidden lg:flex items-center gap-2 px-3 py-1 bg-[#FAF4E6] border border-[#F2E5C9] rounded-full text-[11px] font-bold text-[#A37E36]">
            <Sparkles className="w-3 h-3 text-[#D8AE5C]" />
            <span>{isRTL ? 'كتالوج المنتجات والخدمات الرسمية' : 'Official Products & Services Suite'}</span>
          </div>

          {/* Right: User Profile & Actions */}
          <div className="flex items-center gap-3.5">
            {/* Language Switcher */}
            <button
              id="portal-language-btn"
              onClick={() => setLang(l => l === 'en' ? 'ar' : 'en')}
              className="flex items-center gap-1 text-xs font-bold text-gray-600 hover:text-[#0A1F3D] px-2.5 py-1.5 rounded-md hover:bg-gray-100 transition-colors"
            >
              <Globe className="w-3.5 h-3.5 text-[#D8AE5C]" />
              <span>{isRTL ? 'English' : 'العربية'}</span>
            </button>

            <div className="h-5 w-[1px] bg-gray-200"></div>

            {/* User Badge */}
            <div className="flex items-center gap-3 bg-gray-50 border border-gray-200/80 px-3 py-1.5 rounded-lg">
              <div className="w-7 h-7 rounded-full bg-[#0A1F3D] text-[#D8AE5C] font-extrabold text-xs flex items-center justify-center shadow-xs">
                {user.name.charAt(0).toUpperCase()}
              </div>
              <div className="hidden sm:block text-left">
                <p className="text-xs font-bold text-[#0A1F3D] leading-none">{user.name}</p>
                <p className="text-[10px] text-gray-500 leading-tight mt-0.5">{user.storeName}</p>
              </div>
              <span className="hidden sm:inline-block bg-emerald-100 text-emerald-700 font-bold text-[9px] px-1.5 py-0.5 rounded">
                {user.plan}
              </span>
            </div>

            {/* Logout Button */}
            <button
              id="portal-logout-btn"
              onClick={onLogout}
              title={isRTL ? 'تسجيل الخروج' : 'Log Out'}
              className="text-gray-400 hover:text-rose-600 p-2 rounded-md hover:bg-rose-50 transition-colors cursor-pointer"
            >
              <LogOut className={`w-4 h-4 ${isRTL ? 'rotate-180' : ''}`} />
            </button>
          </div>

        </div>
      </header>

      {/* PORTAL HERO & STATS HEADER */}
      <section className="bg-white border-b border-gray-200/80 py-8 px-6 lg:px-10">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div>
            <div className="flex items-center gap-2 mb-1.5">
              <span className="text-xs font-extrabold text-[#D8AE5C] uppercase tracking-wider">
                {isRTL ? 'لوحة الخدمات والحلول' : 'MERCHANT PRODUCTS HUB'}
              </span>
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-500"></span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-black text-[#0A1F3D] tracking-tight">
              {isRTL 
                ? `مرحباً ${user.name}، استكشف كافة منتجات وخدمات نكستليفاي` 
                : `Welcome ${user.name}, Explore All Products & Services`}
            </h1>
            <p className="text-xs sm:text-sm text-gray-500 mt-1 max-w-2xl">
              {isRTL 
                ? `الحلول المفعلة متصلة بمتجرك (${user.storeName}) عبر (${user.platform}) وتعمل بأتمتة كاملة.`
                : `Active solutions are synchronized with your store (${user.storeName}) on ${user.platform}.`}
            </p>
          </div>

          {/* Quick Status Stats */}
          <div className="flex items-center gap-3 sm:gap-4 shrink-0">
            <div className="bg-[#FAF4E6] border border-[#F2E5C9] p-3 rounded-xl text-center min-w-[110px]">
              <p className="text-[10px] font-bold text-[#A37E36] uppercase">{isRTL ? 'المنتجات النشطة' : 'Active Modules'}</p>
              <p className="text-xl font-black text-[#0A1F3D] mt-0.5">{activatedProducts.length} / {PRODUCTS_DATA.length}</p>
            </div>
            <div className="bg-gray-50 border border-gray-200 p-3 rounded-xl text-center min-w-[110px]">
              <p className="text-[10px] font-bold text-gray-500 uppercase">{isRTL ? 'حالة النظام' : 'Engine Health'}</p>
              <p className="text-xs font-black text-emerald-600 mt-1.5 flex items-center justify-center gap-1">
                <CheckCircle2 className="w-3.5 h-3.5" /> 100% Operational
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* FILTER & SEARCH BAR */}
      <section className="max-w-7xl mx-auto w-full px-6 lg:px-10 pt-8 pb-4">
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-4">
          
          {/* Category Tabs */}
          <div className="flex items-center gap-2 overflow-x-auto pb-1 text-xs font-semibold">
            <button
              id="filter-all"
              onClick={() => setSelectedCategory('all')}
              className={`px-4 py-2 rounded-lg transition-all cursor-pointer whitespace-nowrap ${
                selectedCategory === 'all'
                  ? 'bg-[#0A1F3D] text-white shadow-xs'
                  : 'bg-white text-gray-600 border border-gray-200 hover:bg-gray-50'
              }`}
            >
              {isRTL ? 'جميع المنتجات والخدمات' : 'All Products & Services'} ({PRODUCTS_DATA.length})
            </button>
            <button
              id="filter-automation"
              onClick={() => setSelectedCategory('automation')}
              className={`px-4 py-2 rounded-lg transition-all cursor-pointer whitespace-nowrap ${
                selectedCategory === 'automation'
                  ? 'bg-[#0A1F3D] text-white shadow-xs'
                  : 'bg-white text-gray-600 border border-gray-200 hover:bg-gray-50'
              }`}
            >
              {isRTL ? 'أتمتة المحادثات' : 'AI Automation'}
            </button>
            <button
              id="filter-publishing"
              onClick={() => setSelectedCategory('publishing')}
              className={`px-4 py-2 rounded-lg transition-all cursor-pointer whitespace-nowrap ${
                selectedCategory === 'publishing'
                  ? 'bg-[#0A1F3D] text-white shadow-xs'
                  : 'bg-white text-gray-600 border border-gray-200 hover:bg-gray-50'
              }`}
            >
              {isRTL ? 'المحتوى والنشر' : 'Content & Publishing'}
            </button>
            <button
              id="filter-commerce"
              onClick={() => setSelectedCategory('commerce')}
              className={`px-4 py-2 rounded-lg transition-all cursor-pointer whitespace-nowrap ${
                selectedCategory === 'commerce'
                  ? 'bg-[#0A1F3D] text-white shadow-xs'
                  : 'bg-white text-gray-600 border border-gray-200 hover:bg-gray-50'
              }`}
            >
              {isRTL ? 'التجارة والدفع' : 'Commerce & Payments'}
            </button>
            <button
              id="filter-services"
              onClick={() => setSelectedCategory('services')}
              className={`px-4 py-2 rounded-lg transition-all cursor-pointer whitespace-nowrap ${
                selectedCategory === 'services'
                  ? 'bg-[#0A1F3D] text-white shadow-xs'
                  : 'bg-white text-gray-600 border border-gray-200 hover:bg-gray-50'
              }`}
            >
              {isRTL ? 'الخدمات المدارة' : 'Managed Services'}
            </button>
          </div>

          {/* Search Input */}
          <div className="relative min-w-[220px]">
            <input
              id="products-search-input"
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder={isRTL ? 'ابحث عن ميزة أو خدمة...' : 'Search products or features...'}
              className="w-full bg-white border border-gray-200 rounded-lg px-3.5 py-2 text-xs text-gray-800 placeholder:text-gray-400 focus:outline-none focus:border-[#0A1F3D] transition-colors"
            />
          </div>

        </div>
      </section>

      {/* PRODUCTS & SERVICES GRID */}
      <main className="max-w-7xl mx-auto w-full px-6 lg:px-10 py-6 flex-1">
        {filteredProducts.length === 0 ? (
          <div className="bg-white rounded-2xl border border-gray-200 p-12 text-center">
            <p className="text-gray-500 text-sm">
              {isRTL ? 'لم يتم العثور على نتائج تطابق بحثك.' : 'No products or services found matching your query.'}
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredProducts.map((product) => {
              const isActivated = activatedProducts.includes(product.id);

              return (
                <div
                  key={product.id}
                  id={`product-card-${product.id}`}
                  className="bg-white rounded-xl border border-gray-200/90 shadow-xs hover:shadow-md transition-all flex flex-col justify-between overflow-hidden relative group hover:border-[#D8AE5C]/60"
                >
                  {/* Card Header Trim */}
                  <div className={`h-1.5 w-full ${isActivated ? 'bg-[#0A1F3D]' : 'bg-gray-200'}`}></div>

                  <div className="p-6">
                    {/* Category Label & Badge */}
                    <div className="flex items-center justify-between gap-2 mb-3">
                      <span className="text-[10px] font-extrabold uppercase text-[#A37E36] tracking-wider">
                        {isRTL ? product.categoryLabelAr : product.categoryLabelEn}
                      </span>

                      {product.badge && (
                        <span className={`text-[9.5px] font-black px-2 py-0.5 rounded uppercase tracking-wider ${
                          product.badgeType === 'active'
                            ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                            : product.badgeType === 'popular'
                            ? 'bg-[#FAF4E6] text-[#A37E36] border border-[#F2E5C9]'
                            : product.badgeType === 'enterprise'
                            ? 'bg-[#0A1F3D] text-white'
                            : 'bg-indigo-50 text-indigo-700 border border-indigo-200'
                        }`}>
                          {product.badge}
                        </span>
                      )}
                    </div>

                    {/* Title */}
                    <h3 className="text-base font-bold text-[#0A1F3D] mb-2 leading-snug">
                      {isRTL ? product.titleAr : product.titleEn}
                    </h3>

                    {/* Description */}
                    <p className="text-xs text-gray-500 leading-relaxed mb-5 min-h-[48px]">
                      {isRTL ? product.descAr : product.descEn}
                    </p>

                    {/* Feature Checkpoints */}
                    <div className="space-y-2 mb-6 pt-3 border-t border-gray-100">
                      {(isRTL ? product.featuresAr : product.featuresEn).map((feat, idx) => (
                        <div key={idx} className="flex items-start gap-2 text-xs text-gray-700">
                          <Check className="w-3.5 h-3.5 text-[#D8AE5C] shrink-0 mt-0.5" />
                          <span className="leading-tight text-[11.5px]">{feat}</span>
                        </div>
                      ))}
                    </div>

                    {/* Key Metric Highlight */}
                    {product.metrics && (
                      <div className="bg-[#FAF4E6]/60 border border-[#F2E5C9]/80 p-2.5 rounded-lg flex items-center justify-between mb-4">
                        <span className="text-[10px] font-bold text-gray-600">
                          {isRTL ? product.metrics.labelAr : product.metrics.labelEn}
                        </span>
                        <span className="text-xs font-black text-[#0A1F3D]">
                          {product.metrics.value}
                        </span>
                      </div>
                    )}
                  </div>

                  {/* Card Footer Actions */}
                  <div className="p-4 bg-gray-50/80 border-t border-gray-100 flex items-center justify-between gap-2">
                    <div className="text-xs font-black text-[#0A1F3D]">
                      {product.priceMonthly}
                    </div>

                    <div className="flex items-center gap-2">
                      <button
                        id={`btn-configure-${product.id}`}
                        onClick={() => setActiveConfigModal(product)}
                        className="bg-white hover:bg-gray-100 text-[#0A1F3D] border border-gray-300 px-3 py-1.5 rounded-md font-bold text-xs transition-colors cursor-pointer flex items-center gap-1"
                      >
                        <Sliders className="w-3 h-3 text-[#D8AE5C]" />
                        <span>{isRTL ? 'إدارة' : 'Configure'}</span>
                      </button>

                      <button
                        id={`btn-toggle-${product.id}`}
                        onClick={() => toggleActivateProduct(product.id)}
                        className={`px-3 py-1.5 rounded-md font-bold text-xs transition-colors cursor-pointer ${
                          isActivated
                            ? 'bg-[#0A1F3D] text-white hover:bg-[#142c50]'
                            : 'bg-[#D8AE5C] hover:bg-[#cb9f4b] text-[#0A1F3D]'
                        }`}
                      >
                        {isActivated 
                          ? (isRTL ? 'مفعّل ✓' : 'Enabled ✓') 
                          : (isRTL ? 'تفعيل الآن' : 'Enable')}
                      </button>
                    </div>
                  </div>

                </div>
              );
            })}
          </div>
        )}
      </main>

      {/* PRODUCT CONFIGURATION & SIMULATION MODAL */}
      {activeConfigModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/65 backdrop-blur-xs p-4 animate-in fade-in duration-200">
          <div 
            className="bg-white rounded-2xl max-w-2xl w-full p-6 sm:p-7 shadow-2xl border border-gray-200 relative overflow-hidden"
            dir={isRTL ? 'rtl' : 'ltr'}
          >
            {/* Close Button */}
            <button
              id="close-config-modal"
              onClick={() => setActiveConfigModal(null)}
              className="absolute top-4 right-4 text-gray-400 hover:text-gray-700 p-1.5 rounded-lg hover:bg-gray-100 transition-colors"
            >
              ✕
            </button>

            {/* Modal Header */}
            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 rounded-xl bg-[#0A1F3D] flex items-center justify-center text-[#D8AE5C] font-extrabold shadow-xs">
                <Cpu className="w-5 h-5" />
              </div>
              <div>
                <span className="text-[10px] font-extrabold uppercase text-[#A37E36] tracking-wider">
                  {isRTL ? activeConfigModal.categoryLabelAr : activeConfigModal.categoryLabelEn}
                </span>
                <h3 className="text-lg font-bold text-[#0A1F3D]">
                  {isRTL ? activeConfigModal.titleAr : activeConfigModal.titleEn}
                </h3>
              </div>
            </div>

            {/* Live Interactive Test Simulator inside Modal */}
            <div className="bg-gray-50 p-4 rounded-xl border border-gray-200 mb-5">
              <div className="flex items-center justify-between pb-2 mb-3 border-b border-gray-200 text-xs font-bold text-[#0A1F3D]">
                <div className="flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
                  <span>{isRTL ? 'اختبار تفاعلي فوري لنموذج الذكاء الاصطناعي' : 'Live Interactive Test Console'}</span>
                </div>
                <span className="text-[10px] text-gray-400 font-mono">{user.storeName}</span>
              </div>

              {/* Chat Log */}
              <div className="space-y-2.5 max-h-[160px] overflow-y-auto pr-1">
                {testChatLog.map((item, idx) => (
                  <div key={idx} className={`flex flex-col ${item.role === 'user' ? 'items-start' : 'items-end'}`}>
                    <div className={`p-2.5 rounded-lg text-xs max-w-[85%] leading-relaxed ${
                      item.role === 'user'
                        ? 'bg-white text-gray-800 border border-gray-200 shadow-2xs'
                        : 'bg-[#0A1F3D] text-white shadow-xs'
                    }`}>
                      {item.text}
                    </div>
                    <span className="text-[9px] text-gray-400 mt-0.5 px-1">{item.time}</span>
                  </div>
                ))}

                {isAiTyping && (
                  <div className="flex items-center gap-1 p-2 bg-gray-200/80 rounded-lg w-12">
                    <span className="w-1 h-1 bg-gray-500 rounded-full animate-bounce"></span>
                    <span className="w-1 h-1 bg-gray-500 rounded-full animate-bounce [animation-delay:0.2s]"></span>
                    <span className="w-1 h-1 bg-gray-500 rounded-full animate-bounce [animation-delay:0.4s]"></span>
                  </div>
                )}
              </div>

              {/* Test Input */}
              <form onSubmit={handleTestSendMessage} className="mt-3 flex gap-2">
                <input
                  type="text"
                  value={testInput}
                  onChange={(e) => setTestInput(e.target.value)}
                  placeholder={isRTL ? 'اكتب تجربة سؤال: كم سعر الشحن؟' : 'Type a sample customer question...'}
                  className="flex-1 bg-white border border-gray-200 rounded-lg px-3 py-1.5 text-xs focus:outline-none focus:border-[#0A1F3D]"
                />
                <button
                  type="submit"
                  className="bg-[#D8AE5C] hover:bg-[#cb9f4b] text-[#0A1F3D] px-3 py-1.5 rounded-lg font-bold text-xs flex items-center justify-center transition-colors"
                >
                  <Send className="w-3.5 h-3.5" />
                </button>
              </form>
            </div>

            {/* Quick Settings Toggles */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mb-5 text-xs">
              <div className="p-3 bg-white border border-gray-200 rounded-lg flex items-center justify-between">
                <div>
                  <p className="font-bold text-[#0A1F3D]">{isRTL ? 'مزامنة السلات والمنتجات' : 'Catalogue Auto-Sync'}</p>
                  <p className="text-[10px] text-gray-500">{user.platform}</p>
                </div>
                <span className="text-emerald-600 font-bold text-[11px]">{isRTL ? 'متصل' : 'Active'}</span>
              </div>
              <div className="p-3 bg-white border border-gray-200 rounded-lg flex items-center justify-between">
                <div>
                  <p className="font-bold text-[#0A1F3D]">{isRTL ? 'اللهجة المفضلة' : 'Default Dialect'}</p>
                  <p className="text-[10px] text-gray-500">{user.region}</p>
                </div>
                <span className="text-[#A37E36] font-bold text-[11px]">{isRTL ? 'مخصص' : 'Custom'}</span>
              </div>
            </div>

            {/* Modal Actions */}
            <div className="flex items-center justify-end gap-3 pt-3 border-t border-gray-100">
              <button
                onClick={() => setActiveConfigModal(null)}
                className="bg-gray-100 hover:bg-gray-200 text-gray-700 px-4 py-2 rounded-lg font-bold text-xs transition-colors"
              >
                {isRTL ? 'إغلاق' : 'Close'}
              </button>
              <button
                onClick={() => {
                  if (!activatedProducts.includes(activeConfigModal.id)) {
                    toggleActivateProduct(activeConfigModal.id);
                  }
                  setActiveConfigModal(null);
                }}
                className="bg-[#0A1F3D] hover:bg-[#142c50] text-white px-5 py-2 rounded-lg font-bold text-xs transition-colors shadow-xs"
              >
                {isRTL ? 'حفظ وتطبيق الإعدادات' : 'Save & Deploy Changes'}
              </button>
            </div>

          </div>
        </div>
      )}

      {/* PORTAL FOOTER */}
      <footer className="bg-white border-t border-gray-200 py-6 px-6 lg:px-10 text-xs text-gray-500 mt-auto">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <NexlifyLogo size="sm" showWordmark={false} />
            <span className="font-bold text-[#0A1F3D]">Nexlify AI Commerce Platform</span>
            <span className="text-gray-400">•</span>
            <span className="text-[11px] text-gray-400">&copy; {new Date().getFullYear()} All rights reserved.</span>
          </div>

          <div className="flex items-center gap-4 text-xs font-semibold text-[#0A1F3D]">
            <button onClick={onBackToHome} className="hover:underline cursor-pointer">
              {isRTL ? 'صفحة الهبوط' : 'Landing Page'}
            </button>
            <span className="text-gray-300">•</span>
            <span>{user.region}</span>
          </div>
        </div>
      </footer>
    </div>
  );
};
