import React from 'react';

interface NexlifyLogoProps {
  className?: string;
  size?: 'sm' | 'md' | 'lg' | 'xl' | number;
  showWordmark?: boolean;
  layout?: 'horizontal' | 'vertical';
  variant?: 'light' | 'dark'; // 'light' for light backgrounds (navy text), 'dark' for dark backgrounds (white text)
}

export const NexlifyIcon: React.FC<{ size?: number; className?: string; inverted?: boolean }> = ({ 
  size = 40, 
  className = '',
  inverted = false 
}) => {
  return (
    <svg 
      width={size} 
      height={size} 
      viewBox="0 0 120 120" 
      fill="none" 
      xmlns="http://www.w3.org/2000/svg"
      className={`shrink-0 ${className}`}
    >
      <defs>
        {/* Metallic Gold Gradient for Corner Bevels */}
        <linearGradient id="nexlifyGold1" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#F5E4A8" />
          <stop offset="35%" stopColor="#D4AF37" />
          <stop offset="70%" stopColor="#B38B28" />
          <stop offset="100%" stopColor="#DDBF6B" />
        </linearGradient>

        <linearGradient id="nexlifyGold2" x1="100%" y1="0%" x2="0%" y2="100%">
          <stop offset="0%" stopColor="#FFF2C6" />
          <stop offset="40%" stopColor="#D4AF37" />
          <stop offset="80%" stopColor="#A07920" />
          <stop offset="100%" stopColor="#C9A13B" />
        </linearGradient>

        {/* Primary Midnight Navy for Main Letterform */}
        <linearGradient id="nexlifyNavyMain" x1="20%" y1="10%" x2="80%" y2="90%">
          <stop offset="0%" stopColor={inverted ? "#183664" : "#0A1F3D"} />
          <stop offset="50%" stopColor={inverted ? "#10294E" : "#06162B"} />
          <stop offset="100%" stopColor={inverted ? "#0B1D38" : "#020B17"} />
        </linearGradient>

        {/* Fold / Interlocking Layer Accent */}
        <linearGradient id="nexlifyNavyFacet" x1="0%" y1="100%" x2="100%" y2="0%">
          <stop offset="0%" stopColor={inverted ? "#204680" : "#0F2D56"} />
          <stop offset="100%" stopColor={inverted ? "#122C54" : "#081C38"} />
        </linearGradient>
      </defs>

      {/* 4 Golden Faceted Corner Brackets */}
      {/* Top Left Gold Bevel */}
      <polygon points="26,38 38,26 50,38 38,50" fill="url(#nexlifyGold1)" />
      
      {/* Top Right Gold Bevel */}
      <polygon points="70,38 82,26 94,38 82,50" fill="url(#nexlifyGold2)" />
      
      {/* Bottom Left Gold Bevel */}
      <polygon points="26,82 38,70 50,82 38,94" fill="url(#nexlifyGold2)" />
      
      {/* Bottom Right Gold Bevel */}
      <polygon points="70,82 82,70 94,82 82,94" fill="url(#nexlifyGold1)" />

      {/* Interconnected Stylized "N" Ribbon */}
      {/* Base N Structure */}
      <path 
        d="M38,82 L38,38 L54,38 L54,66 L66,38 L82,38 L82,82 L66,82 L66,54 L54,82 Z" 
        fill="url(#nexlifyNavyMain)" 
      />

      {/* Ribbon Diagonal Overlap Highlight */}
      <polygon 
        points="54,62 66,38 82,38 54,82" 
        fill="url(#nexlifyNavyFacet)" 
      />

      {/* Subtle Inner Cut Geometry */}
      <polygon points="38,38 54,38 38,60" fill="url(#nexlifyNavyMain)" opacity="0.9" />
      <polygon points="66,60 82,82 66,82" fill="url(#nexlifyNavyMain)" opacity="0.9" />
    </svg>
  );
};

export const NexlifyLogo: React.FC<NexlifyLogoProps> = ({
  className = '',
  size = 'md',
  showWordmark = true,
  layout = 'horizontal',
  variant = 'light'
}) => {
  const pixelSize = typeof size === 'number' ? size : {
    sm: 30,
    md: 40,
    lg: 52,
    xl: 72
  }[size];

  const isDark = variant === 'dark';
  const isVertical = layout === 'vertical';

  return (
    <div className={`inline-flex ${isVertical ? 'flex-col items-center text-center' : 'items-center gap-3.5'} ${className}`}>
      <div className="relative flex items-center justify-center transition-transform hover:scale-105 duration-200">
        <NexlifyIcon size={pixelSize} inverted={isDark} />
      </div>
      
      {showWordmark && (
        <div className={`flex flex-col ${isVertical ? 'items-center mt-2' : 'justify-center'}`}>
          <span 
            className={`font-black tracking-tight leading-none ${
              isDark ? 'text-white' : 'text-[#0A1F3D]'
            }`}
            style={{ 
              fontSize: `${Math.round(pixelSize * 0.62)}px`,
              letterSpacing: '-0.035em'
            }}
          >
            Nexlify
          </span>
          <span 
            className="text-[#D4AF37] font-extrabold uppercase tracking-widest leading-tight"
            style={{ 
              fontSize: `${Math.max(8.5, Math.round(pixelSize * 0.23))}px`,
              marginTop: isVertical ? '4px' : '2px',
              letterSpacing: '0.14em'
            }}
          >
            GCC AI COMMERCE
          </span>
        </div>
      )}
    </div>
  );
};

export default NexlifyLogo;
